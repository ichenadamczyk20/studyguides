# studyguides
Freshmen (or the more experienced sophomores) can submit study guides for other freshmen through this website made by the Freshmen Caucus (and their IT team of Ian Chen-Adamczyk and Victor Veytsmann). Created Spring 2019 and (maybe) still maintained.

Made with Go, SQLite, Quill.JS, JavaScript, HTML, and CSS

## Tasks
These are the tasks we need to complete

### Backend
* [ ] cleanup code
* [ ] use postgresql

### Frontend
* [ ] more styles?
* [ ] search bar

### Backend + Frontend
* [ ] users
* [ ] comments/votes (distant future)

### Misc.
* [ ] hosting
